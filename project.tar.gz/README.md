# Cloud-Based Distributed Image Processing and Task Scheduling System

> **Course**: Cloud and Distributed Computing (CDC)  
> **Architecture**: React (Vite + TS) + FastAPI + Celery + Redis + MongoDB + Docker + AWS S3

A production-minded distributed image processing and task scheduling platform engineered to demonstrate core distributed systems concepts: asynchronous queuing, horizontal worker scaling, late acknowledgements, fault-tolerant crash recovery, shared persistent storage, and empirical performance benchmarking.

---

## Architecture Overview

```
                                      +------------------------------------+
                                      |          React 19 Frontend         |
                                      |   (Vite + TypeScript + Tailwind)   |
                                      +-----------------+------------------+
                                                        |
                                              HTTP / REST API Calls
                                                        |
                                                        v
                                      +-----------------+------------------+
                                      |         FastAPI Gateway            |
                                      |    (Validation + Auth + CRUD)      |
                                      +--------+--------+---------+--------+
                                               |        |         |
                          +--------------------+        |         +-------------------+
                          | Metadata & State            | Task Enqueue                | Binary Files
                          v                             v                             v
               +----------+---------+         +---------+---------+        +----------+---------+
               |      MongoDB       |         |   Redis Broker    |        |   Shared Storage   |
               | (Tasks, Batches,   |         |   (Task Queue     |        | (Docker Volume or  |
               |  Benchmarks)       |         |   & Results)      |        |  AWS S3 Bucket)    |
               +----------+---------+         +---------+---------+        +----------+---------+
                          ^                             |                             ^
                          |                             | Pull Jobs (Fair Prefetch)   | Read/Write
                          |                             v                             |
                          |                   +---------+---------+                   |
                          +-------------------|   Celery Worker   |-------------------+
                          | Updates State     |  Nodes (1..N)     |
                          +-------------------|  (Pillow Engine)  |-------------------+
```

---

## Key Features

1. **8 Image Processing Operations**:
   - Resize to custom width and height
   - Aspect-ratio preserving thumbnails
   - Compress with adjustable quality factor (1–100%)
   - Format conversion between JPEG, PNG, and WebP
   - Rotation with canvas expansion
   - Grayscale conversion (monochrome luminance)
   - Gaussian blur with adjustable pixel radius
   - Metadata extraction (dimensions, format, color mode, file size, EXIF tags)
2. **Distributed Pipeline**:
   - Asynchronous decoupled processing via Celery and Redis.
   - Fair task prefetching (`worker_prefetch_multiplier = 1`).
   - Late acknowledgements (`task_acks_late = True`) ensuring tasks are recovered on worker node crash.
   - Idempotent execution preventing duplicate file creation on retries.
   - Shared storage for binary files; Redis holds only lightweight task metadata.
3. **Responsive Web Dashboard**:
   - **Dashboard**: Real-time throughput metrics, hourly volume area chart, worker utilization bar chart, recent task stream.
   - **Upload & Process**: Drag-and-drop zone, multi-image preview, operation selector, configuration controls, upload progress bar.
   - **Task Monitor**: Searchable and filterable task table, task inspection modal, output previews, retry action, individual and ZIP download.
   - **Worker Monitor**: Live Celery worker status, Redis queue depth, task throughput, heartbeats, remote pause/resume controls.
   - **Performance Benchmark**: 1 vs 2 vs 4 worker comparison measuring wall-clock time, speedup ($S_N$), and efficiency ($E_N$).
   - **Task History**: Chronological batch archives with bulk ZIP downloads.
4. **Dual Deployment Modes**:
   - **Local Mode**: Complete multi-container environment orchestrated via `docker-compose.yml`.
   - **Cloud Mode**: AWS EC2 multi-node architecture utilizing private VPC networking and Amazon S3 object storage.

---

## Repository Structure

```
project/
├── backend/
│   ├── app/
│   │   ├── api/                   # REST API route handlers
│   │   ├── models/                # Pydantic schemas (Task, Batch, Benchmark, Worker)
│   │   ├── services/              # Storage (local/S3) and Pillow ImageProcessor
│   │   ├── tasks/                 # Celery app and image processing tasks
│   │   ├── config.py              # Environment configuration
│   │   ├── database.py            # Motor (async) and PyMongo (sync) connections
│   │   └── main.py                # FastAPI application entrypoint
│   ├── tests/                     # 21 automated pytest integration/unit tests
│   ├── Dockerfile                 # Backend container definition
│   └── requirements.txt           # Python dependencies
├── frontend/
│   ├── src/
│   │   ├── api/                   # Typed Axios API client
│   │   ├── components/            # UI components (dashboard, tasks, upload, etc.)
│   │   ├── hooks/                 # Reusable polling and state hooks
│   │   ├── pages/                 # Full dashboard pages
│   │   └── types/                 # TypeScript type interfaces
│   ├── Dockerfile                 # Multi-stage production Nginx container
│   ├── nginx.conf                 # SPA routing and API reverse-proxy configuration
│   └── package.json               # Node.js dependencies
├── docs/
│   ├── architecture.md            # Detailed system architecture
│   ├── api.md                     # Comprehensive REST API reference
│   ├── deployment-aws.md          # Step-by-step AWS EC2 deployment guide
│   ├── benchmark-procedure.md     # Benchmark & controlled failure procedure
│   └── project-report.md          # CDC university course report
├── docker-compose.yml             # Local multi-service orchestration
├── docker-compose.cloud.yml       # Cloud AWS production configuration
├── .env.example                   # Environment configuration template
└── README.md                      # Project documentation
```

---

## Quickstart Instructions

### 1. Prerequisites
- [Docker](https://www.docker.com/) & Docker Compose
- Or Python 3.10+ and Node.js 18+ for local non-containerized execution.

### 2. Configure Environment
Copy the environment template:
```bash
# Windows PowerShell
Copy-Item .env.example .env

# Linux / macOS
cp .env.example .env
```

### 3. Launch via Docker Compose (Recommended)

Start all services (MongoDB, Redis, API Gateway, 2 Celery Workers, and Frontend Nginx):
```bash
docker compose up --build -d
```

Access the interfaces:
- **Frontend Dashboard**: `http://localhost:80` (or `http://localhost:5173` in dev mode)
- **FastAPI Interactive Docs**: `http://localhost:8000/api/docs`
- **Health Check**: `http://localhost:8000/api/health`

### 4. Horizontally Scaling Worker Nodes

Scale Celery workers up to 4 or 8 nodes with zero downtime:
```bash
docker compose up --scale worker-1=4 -d
```
All new worker instances immediately connect to Redis and begin consuming tasks.

---

## Running Automated Tests

### Backend Test Suite (Pytest)
Run the automated test suite covering all 8 image operations, uploads, and endpoints:
```bash
# Windows PowerShell
$env:PYTHONPATH="backend"; py -m pytest backend/tests -v

# Linux / macOS
PYTHONPATH=backend pytest backend/tests -v
```
**Results**: 21 passed, 0 failed (100% pass rate).

### Frontend Build & Typecheck
Verify frontend compilation and type safety:
```bash
cd frontend
npm run build
```

---

## Documentation Links

- [System Architecture](docs/architecture.md)
- [REST API Reference](docs/api.md)
- [AWS Deployment Guide](docs/deployment-aws.md)
- [Benchmark & Failure Simulation Procedure](docs/benchmark-procedure.md)
- [CDC Project Academic Report](docs/project-report.md)

---

## License & Academic Notice

Built for the **Cloud and Distributed Computing (CDC)** university semester curriculum. All rights reserved.
